    #ifndef FRUIT_H
    #define FRUIT_H

    #include <QGraphicsRectItem>
    #include <QObject>
    #include <QGraphicsItem>
    #include <QGraphicsPixmapItem>
    #include <QTimer>
    #include <QGraphicsScene>
    #include <QList>
    #include <QDebug>
    #include <QString>
    #include <QDebug>
    #include <typeinfo>
    #include "Game.h"

    class Fruit: public QObject,public QGraphicsPixmapItem{
        Q_OBJECT
    public:
        static int lastFruit;
        Fruit(QGraphicsItem * parent=0);

    public slots:
        void move();
    };
        #endif // FRUIT_H
